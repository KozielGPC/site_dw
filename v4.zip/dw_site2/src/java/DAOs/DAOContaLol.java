package DAOs;

import Entidades.ContaLol;
import java.util.ArrayList;
import java.util.List;

public class DAOContaLol extends DAOGenerico<ContaLol> {

    public DAOContaLol() {
        super(ContaLol.class);
    }

    public int autoIdContaLol() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.idContaLol) FROM ContaLol e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<ContaLol> listByNome(String nome) {
        return em.createQuery("SELECT e FROM ContaLol e WHERE e.nomeContaLol LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<ContaLol> listById(int id) {
        return em.createQuery("SELECT e FROM ContaLol e WHERE e.idContaLol = :id").setParameter("id", id).getResultList();
    }

    public List<ContaLol> listInOrderNome() {
        return em.createQuery("SELECT e FROM ContaLol e ORDER BY e.nomeContaLol").getResultList();
    }

    public List<ContaLol> listInOrderId() {
        return em.createQuery("SELECT e FROM ContaLol e ORDER BY e.idContaLol").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<ContaLol> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }

        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getIdcontaLol()+ "-" + lf.get(i).getNick());
        }
        return ls;
    }
}
