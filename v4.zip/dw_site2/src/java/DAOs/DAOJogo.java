package DAOs;

import Entidades.Jogo;
import java.util.ArrayList;
import java.util.List;

public class DAOJogo extends DAOGenerico<Jogo> {

    public DAOJogo() {
        super(Jogo.class);
    }

    public int autoIdJogo() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.idjogo) FROM Jogo e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Jogo> listByNome(String nome) {
        return em.createQuery("SELECT e FROM Jogo e WHERE e.nomeJogo LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<Jogo> listById(int id) {
        return em.createQuery("SELECT e FROM Jogo e WHERE e.idjogo = :id").setParameter("id", id).getResultList();
    }

    public List<Jogo> listInOrderNome() {
        return em.createQuery("SELECT e FROM Jogo e ORDER BY e.nomeJogo").getResultList();
    }

    public List<Jogo> listInOrderId() {
        return em.createQuery("SELECT e FROM Jogo e ORDER BY e.idjogo").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Jogo> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }

        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getIdjogo()+ "-" + lf.get(i).getNomeJogo());
        }
        return ls;
    }
}
