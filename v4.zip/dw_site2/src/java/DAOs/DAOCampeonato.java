package DAOs;

import Entidades.Campeonato;
import java.util.ArrayList;
import java.util.List;

public class DAOCampeonato extends DAOGenerico<Campeonato> {

    public DAOCampeonato() {
        super(Campeonato.class);
    }

    public int autoIdCampeonato() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.idCampeonato) FROM Campeonato e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Campeonato> listByNome(String nome) {
        return em.createQuery("SELECT e FROM Campeonato e WHERE e.nomeCampeonato LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<Campeonato> listById(int id) {
        return em.createQuery("SELECT e FROM Campeonato e WHERE e.idCampeonato = :id").setParameter("id", id).getResultList();
    }

    public List<Campeonato> listInOrderNome() {
        return em.createQuery("SELECT e FROM Campeonato e ORDER BY e.nomeCampeonato").getResultList();
    }

    public List<Campeonato> listInOrderId() {
        return em.createQuery("SELECT e FROM Campeonato e ORDER BY e.idCampeonato").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Campeonato> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }

        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getIdcampeonato()+ "-" + lf.get(i).getNome());
        }
        return ls;
    }
}
