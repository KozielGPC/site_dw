package DAOs;

import Entidades.Recompensa;
import java.util.ArrayList;
import java.util.List;

public class DAORecompensa extends DAOGenerico<Recompensa> {

    public DAORecompensa() {
        super(Recompensa.class);
    }

    public int autoIdRecompensa() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.idRecompensa) FROM Recompensa e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Recompensa> listByNome(String nome) {
        return em.createQuery("SELECT e FROM Recompensa e WHERE e.nomeRecompensa LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<Recompensa> listById(int id) {
        return em.createQuery("SELECT e FROM Recompensa e WHERE e.idrecompensa = :id").setParameter("id", id).getResultList();
    }

    public List<Recompensa> listInOrderNome() {
        return em.createQuery("SELECT e FROM Recompensa e ORDER BY e.nomeRecompensa").getResultList();
    }

    public List<Recompensa> listInOrderId() {
        return em.createQuery("SELECT e FROM Recompensa e ORDER BY e.idrecompensa").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Recompensa> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }

        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getIdrecompensa()+ "-" + lf.get(i).getNomeRecompensa());
        }
        return ls;
    }
}
