package DAOs;

import Entidades.Time;
import java.util.ArrayList;
import java.util.List;

public class DAOTime extends DAOGenerico<Time> {

    public DAOTime() {
        super(Time.class);
    }

    public int autoIdTime() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.idtime) FROM Time e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Time> listByNome(String nome) {
        return em.createQuery("SELECT e FROM Time e WHERE e.nome LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<Time> listById(int id) {
        return em.createQuery("SELECT e FROM Time e WHERE e.idtime = :id").setParameter("id", id).getResultList();
    }

    public List<Time> listInOrderNome() {
        return em.createQuery("SELECT e FROM Time e ORDER BY e.nome").getResultList();
    }

    public List<Time> listInOrderId() {
        return em.createQuery("SELECT e FROM Time e ORDER BY e.idtime").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Time> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }

        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getIdtime()+ "-" + lf.get(i).getNome());
        }
        return ls;
    }
}
