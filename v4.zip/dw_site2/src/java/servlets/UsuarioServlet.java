/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import DAOs.DAOGenerico;
import DAOs.DAOUsuario;
import Entidades.Usuario;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author gpcga
 */
@WebServlet(name = "UsuarioServlet", urlPatterns = {"/usuario"})
public class UsuarioServlet extends HttpServlet {

    

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */


    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        DAOUsuario daoUsuario = new DAOUsuario();
        Usuario usuario = new Usuario();
        List<Usuario> listaUsuario;
        listaUsuario = daoUsuario.listInOrderId();
        String acao = request.getParameter("acao");
        String editando = request.getParameter("nome");
        switch (acao) {
            case "login":
                for (Usuario t : listaUsuario) {
                    System.out.println(t);
                    if (t.getLogin().equals(request.getParameter("login"))  && t.getSenha().equals(request.getParameter("senha"))) {
                        usuario.setIdusuario(t.getIdusuario());
                        usuario.setSenha(t.getSenha());
                        usuario.setEmail(t.getEmail());
                        usuario.setNome(t.getNome());
                        usuario.setLogin(t.getLogin());
                        usuario.setCidade(t.getCidade());
                        usuario.setEstado(t.getEstado());
                        usuario.setPais(t.getPais());
                        daoUsuario.setIdLogado(t.getIdusuario());
                        //System.out.println(daoUsuario.getIdLogado());
                        request.setAttribute("usuario", usuario);
                        request.getRequestDispatcher("index.jsp").forward(request, response);
                    } else {

                    }

                }
                break;
        }


        request.setAttribute("listaProduto", listaUsuario);

        try (PrintWriter out = response.getWriter()) {
            request.getRequestDispatcher("index.jsp").forward(request, response);

        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
