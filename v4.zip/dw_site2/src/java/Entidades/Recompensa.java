/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author gpcga
 */
@Entity
@Table(name = "recompensa")
@NamedQueries({
    @NamedQuery(name = "Recompensa.findAll", query = "SELECT r FROM Recompensa r")})
public class Recompensa implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idrecompensa")
    private Integer idrecompensa;
    @Basic(optional = false)
    @Column(name = "nome_recompensa")
    private String nomeRecompensa;
    @Basic(optional = false)
    @Column(name = "valor_recompensa")
    private int valorRecompensa;
    @JoinTable(name = "usuario_has_recompensa", joinColumns = {
        @JoinColumn(name = "recompensa_idrecompensa", referencedColumnName = "idrecompensa")}, inverseJoinColumns = {
        @JoinColumn(name = "usuario_idusuario", referencedColumnName = "idusuario")})
    @ManyToMany
    private List<Usuario> usuarioList;

    public Recompensa() {
    }

    public Recompensa(Integer idrecompensa) {
        this.idrecompensa = idrecompensa;
    }

    public Recompensa(Integer idrecompensa, String nomeRecompensa, int valorRecompensa) {
        this.idrecompensa = idrecompensa;
        this.nomeRecompensa = nomeRecompensa;
        this.valorRecompensa = valorRecompensa;
    }

    public Integer getIdrecompensa() {
        return idrecompensa;
    }

    public void setIdrecompensa(Integer idrecompensa) {
        this.idrecompensa = idrecompensa;
    }

    public String getNomeRecompensa() {
        return nomeRecompensa;
    }

    public void setNomeRecompensa(String nomeRecompensa) {
        this.nomeRecompensa = nomeRecompensa;
    }

    public int getValorRecompensa() {
        return valorRecompensa;
    }

    public void setValorRecompensa(int valorRecompensa) {
        this.valorRecompensa = valorRecompensa;
    }

    public List<Usuario> getUsuarioList() {
        return usuarioList;
    }

    public void setUsuarioList(List<Usuario> usuarioList) {
        this.usuarioList = usuarioList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idrecompensa != null ? idrecompensa.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Recompensa)) {
            return false;
        }
        Recompensa other = (Recompensa) object;
        if ((this.idrecompensa == null && other.idrecompensa != null) || (this.idrecompensa != null && !this.idrecompensa.equals(other.idrecompensa))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entidades.Recompensa[ idrecompensa=" + idrecompensa + " ]";
    }
    
}
