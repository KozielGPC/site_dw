/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author gpcga
 */
@Entity
@Table(name = "jogo")
@NamedQueries({
    @NamedQuery(name = "Jogo.findAll", query = "SELECT j FROM Jogo j")})
public class Jogo implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idjogo")
    private Integer idjogo;
    @Basic(optional = false)
    @Column(name = "nome_jogo")
    private String nomeJogo;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "jogoIdjogo")
    private List<ContaLol> contaLolList;

    public Jogo() {
    }

    public Jogo(Integer idjogo) {
        this.idjogo = idjogo;
    }

    public Jogo(Integer idjogo, String nomeJogo) {
        this.idjogo = idjogo;
        this.nomeJogo = nomeJogo;
    }

    public Integer getIdjogo() {
        return idjogo;
    }

    public void setIdjogo(Integer idjogo) {
        this.idjogo = idjogo;
    }

    public String getNomeJogo() {
        return nomeJogo;
    }

    public void setNomeJogo(String nomeJogo) {
        this.nomeJogo = nomeJogo;
    }

    public List<ContaLol> getContaLolList() {
        return contaLolList;
    }

    public void setContaLolList(List<ContaLol> contaLolList) {
        this.contaLolList = contaLolList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idjogo != null ? idjogo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Jogo)) {
            return false;
        }
        Jogo other = (Jogo) object;
        if ((this.idjogo == null && other.idjogo != null) || (this.idjogo != null && !this.idjogo.equals(other.idjogo))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entidades.Jogo[ idjogo=" + idjogo + " ]";
    }
    
}
