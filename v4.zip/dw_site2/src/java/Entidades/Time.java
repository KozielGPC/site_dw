/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author gpcga
 */
@Entity
@Table(name = "time")
@NamedQueries({
    @NamedQuery(name = "Time.findAll", query = "SELECT t FROM Time t")})
public class Time implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idtime")
    private Integer idtime;
    @Basic(optional = false)
    @Column(name = "nome")
    private String nome;
    @Basic(optional = false)
    @Column(name = "descricao")
    private String descricao;
    @Column(name = "jogador1")
    private String jogador1;
    @Column(name = "jogador2")
    private String jogador2;
    @Column(name = "jogador3")
    private String jogador3;
    @Column(name = "jogador4")
    private String jogador4;
    @Column(name = "jogador5")
    private String jogador5;
    @ManyToMany(mappedBy = "timeList")
    private List<Campeonato> campeonatoList;
    @ManyToMany(mappedBy = "timeList")
    private List<ContaLol> contaLolList;

    public Time() {
    }

    public Time(Integer idtime) {
        this.idtime = idtime;
    }

    public Time(Integer idtime, String nome, String descricao) {
        this.idtime = idtime;
        this.nome = nome;
        this.descricao = descricao;
    }

    public Integer getIdtime() {
        return idtime;
    }

    public void setIdtime(Integer idtime) {
        this.idtime = idtime;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getJogador1() {
        return jogador1;
    }

    public void setJogador1(String jogador1) {
        this.jogador1 = jogador1;
    }

    public String getJogador2() {
        return jogador2;
    }

    public void setJogador2(String jogador2) {
        this.jogador2 = jogador2;
    }

    public String getJogador3() {
        return jogador3;
    }

    public void setJogador3(String jogador3) {
        this.jogador3 = jogador3;
    }

    public String getJogador4() {
        return jogador4;
    }

    public void setJogador4(String jogador4) {
        this.jogador4 = jogador4;
    }

    public String getJogador5() {
        return jogador5;
    }

    public void setJogador5(String jogador5) {
        this.jogador5 = jogador5;
    }

    public List<Campeonato> getCampeonatoList() {
        return campeonatoList;
    }

    public void setCampeonatoList(List<Campeonato> campeonatoList) {
        this.campeonatoList = campeonatoList;
    }

    public List<ContaLol> getContaLolList() {
        return contaLolList;
    }

    public void setContaLolList(List<ContaLol> contaLolList) {
        this.contaLolList = contaLolList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idtime != null ? idtime.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Time)) {
            return false;
        }
        Time other = (Time) object;
        if ((this.idtime == null && other.idtime != null) || (this.idtime != null && !this.idtime.equals(other.idtime))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entidades.Time[ idtime=" + idtime + " ]";
    }
    
}
