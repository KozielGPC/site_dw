/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author gpcga
 */
@Entity
@Table(name = "conta_lol")
@NamedQueries({
    @NamedQuery(name = "ContaLol.findAll", query = "SELECT c FROM ContaLol c")})
public class ContaLol implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idconta_lol")
    private Integer idcontaLol;
    @Basic(optional = false)
    @Column(name = "nick")
    private String nick;
    @Basic(optional = false)
    @Column(name = "horario_joga")
    private String horarioJoga;
    @Basic(optional = false)
    @Column(name = "posicao")
    private String posicao;
    @JoinTable(name = "time_has_conta_lol", joinColumns = {
        @JoinColumn(name = "conta_lol_idconta_lol", referencedColumnName = "idconta_lol")}, inverseJoinColumns = {
        @JoinColumn(name = "time_idtime", referencedColumnName = "idtime")})
    @ManyToMany
    private List<Time> timeList;
    @JoinColumn(name = "jogo_idjogo", referencedColumnName = "idjogo")
    @ManyToOne(optional = false)
    private Jogo jogoIdjogo;
    @JoinColumn(name = "usuario_idusuario", referencedColumnName = "idusuario")
    @ManyToOne(optional = false)
    private Usuario usuarioIdusuario;

    public ContaLol() {
    }

    public ContaLol(Integer idcontaLol) {
        this.idcontaLol = idcontaLol;
    }

    public ContaLol(Integer idcontaLol, String nick, String horarioJoga, String posicao) {
        this.idcontaLol = idcontaLol;
        this.nick = nick;
        this.horarioJoga = horarioJoga;
        this.posicao = posicao;
    }

    public Integer getIdcontaLol() {
        return idcontaLol;
    }

    public void setIdcontaLol(Integer idcontaLol) {
        this.idcontaLol = idcontaLol;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public String getHorarioJoga() {
        return horarioJoga;
    }

    public void setHorarioJoga(String horarioJoga) {
        this.horarioJoga = horarioJoga;
    }

    public String getPosicao() {
        return posicao;
    }

    public void setPosicao(String posicao) {
        this.posicao = posicao;
    }

    public List<Time> getTimeList() {
        return timeList;
    }

    public void setTimeList(List<Time> timeList) {
        this.timeList = timeList;
    }

    public Jogo getJogoIdjogo() {
        return jogoIdjogo;
    }

    public void setJogoIdjogo(Jogo jogoIdjogo) {
        this.jogoIdjogo = jogoIdjogo;
    }

    public Usuario getUsuarioIdusuario() {
        return usuarioIdusuario;
    }

    public void setUsuarioIdusuario(Usuario usuarioIdusuario) {
        this.usuarioIdusuario = usuarioIdusuario;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idcontaLol != null ? idcontaLol.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ContaLol)) {
            return false;
        }
        ContaLol other = (ContaLol) object;
        if ((this.idcontaLol == null && other.idcontaLol != null) || (this.idcontaLol != null && !this.idcontaLol.equals(other.idcontaLol))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entidades.ContaLol[ idcontaLol=" + idcontaLol + " ]";
    }
    
}
